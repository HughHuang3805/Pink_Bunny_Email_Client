package demo;

import io.dropwizard.Configuration;

public class Config extends Configuration {
}
